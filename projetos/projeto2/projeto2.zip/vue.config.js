module.exports = {
    runtimeCompiler: true
}
